package com.Product_Management.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import com.Product_Management.Entity.customer;
import com.Product_Management.Repository.Customer_Dao;

@Service
public class Customer_Service{

	@Autowired
	Customer_Dao dao;

	public List getcustomerbyid(int id) {
		return dao.getcustomerbyid(id);
	}

	public String addcustomer(customer c) {
		return dao.addcustomer(c);
	}

	public String updatecustomer(customer c) {
		return dao.updatecustomers(c);
	}

	public String deletecustomer(int id) {
		return dao.deletecustomerbyid(id);
	}

	public List getonlycustomers() {
		return dao.getonlycustomers();
	}

	public List<customer> getallcustomers() {
		return dao.getallcustomers();
	}

	public List customerOrder() {
		return dao.customerOrder();
	}

}
