package com.Product_Management.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Product_Management.Entity.product;
import com.Product_Management.Repository.Product_Dao;

@Service
public class Product_Service {

	@Autowired
	Product_Dao dao;

	public List getallproduct() {
		// TODO Auto-generated method stub
		return dao.getallproduct();
	}

	public List getproductbyid(int id) {
		return dao.getproductbyid(id);
	}

	public String addproduct(product p) {
		return dao.addproduct(p);
	}
	
	public String updateproductbyid(product p) {
		return dao.updateproductbyid(p);
	}
	
	public String deleteproductbyid(int id) {
		return dao.deleteproductbyid(id);
	}

}
